package com.queue.Springqueue.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;

public class Banking {

	@Id
	long userNumber;
	Date date;
	String typeOfReq;

	/*
	 * @DBRef User user;
	 * 
	 * public User getUser() { return user; } public void setUser(User user) {
	 * this.user = user; }
	 */
	public long getUserNumber() {
		return userNumber;
	}
	public void setUserNumber(long userNumber) {
		this.userNumber = userNumber;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getTypeOfReq() {
		return typeOfReq;
	}
	public void setTypeOfReq(String typeOfReq) {
		this.typeOfReq = typeOfReq;
	}
	
	
}
