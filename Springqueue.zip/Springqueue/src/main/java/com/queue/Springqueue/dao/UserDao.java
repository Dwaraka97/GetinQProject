package com.queue.Springqueue.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import com.queue.Springqueue.model.User;
@Component
public class UserDao {

	@Autowired
	private MongoTemplate mongoTemplate;
	
	public User register(User user) {
		mongoTemplate.save(user);
		return user;
	}
	
	public User getUserNo(long number) {
	Query query = new Query();
	query.addCriteria(Criteria.where("userNumber").is(number));
	return mongoTemplate.findOne(query, User.class);
}
}
