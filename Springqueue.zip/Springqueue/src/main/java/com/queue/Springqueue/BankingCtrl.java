package com.queue.Springqueue;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.queue.Springqueue.dao.*;
import com.queue.Springqueue.model.*;

/*import com.queue.Springqueue.service.*;*/
@CrossOrigin
@RestController
public class BankingCtrl {

	
	  
	 
	@Autowired
	UserDao userd;
	@PostMapping(value="user")
	public User Register(@RequestBody User user)
	{

		return userd.register(user);
	}
	
	
	@GetMapping(value="user/{userNumber}") 
	public Object getRest(@PathVariable long userNumber ) 
	{ 
		return userd.getUserNo(userNumber);
	  }
	
	@Autowired BankingDao bankingDao;
	  
	  
	  @PostMapping(value="banking") 
	  public Banking create(@RequestBody Banking banking) {
	  
	  return bankingDao.createToken(banking); }
	/*
	 * @GetMapping(value="resturant") public ArrayList<Resturant> getAllRest() {
	 * return bankingService.getResturants();
	 * 
	 * }
	 * 
	 * 
	 * 
	 * 
	 * @DeleteMapping(value="resturant/{resturantId}") public String
	 * deleteRest(@PathVariable int resturantId ) { return
	 * bankingService.deleteResturant(resturantId);
	 * 
	 * }
	 * 
	 * @PutMapping(value="resturant") public String updateRest(@RequestBody
	 * Resturant resturant ) { return bankingService.updateResturant(resturant);
	 * 
	 * }
	 * 
	 */
	
}
