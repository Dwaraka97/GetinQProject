package com.queue.Springqueue.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;
import com.queue.Springqueue.model.*;
import com.queue.Springqueue.dao.*;
@Component
public class BankingDao {

	@Autowired
	private MongoTemplate mongoTemplate;


	@Autowired
	UserDao dao;
/*	public List<Resturant> getAllResturants() {
		return mongoTemplate.findAll(Resturant.class);
	}*/

	/*public Resturant getResturantById(String resturantId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("resturantId").is(resturantId));
		return mongoTemplate.findOne(query, Resturant.class);
	}*/

	public Banking createToken(Banking banking) {
		
		
		/*
		 * User user= dao.getUserNo();
		 * 
		 * banking.setUserNumber(user.getUserNumber());
		 */
		 
		  mongoTemplate.save(banking);
		 
		return banking;
	}

	/*public Object getAllResturantItems(String resturantId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("resturantId").is(resturantId));
		Resturant resturant = mongoTemplate.findOne(query, Resturant.class);
		return resturant != null ? resturant.getResturantItems() : "Resturant not found.";
	}

	
	public String getResturantItems(String resturnId, String key) {
		Query query = new Query();
		query.fields().include("resturantItems");
		query.addCriteria(Criteria.where("resturantId").is(resturnId).andOperator(Criteria.where("resturantItems." + key).exists(true)));
		Resturant resturant = mongoTemplate.findOne(query, Resturant.class);
		return resturant != null ? resturant.getResturantItems().get(key) : "Not found.";
	}

	
	public String addResturantItems(String resturantId, String key, String value) {
		Query query = new Query();
		query.addCriteria(Criteria.where("resturantId").is(resturantId));
		Resturant resturant = mongoTemplate.findOne(query, Resturant.class);
		if (resturant != null) {
			resturant.getResturantItems().put(key, value);
			mongoTemplate.save(resturant);
			return "Key added.";
		} else {
			return "Resturant not found.";
		}
	}*/

	
}

	
	
