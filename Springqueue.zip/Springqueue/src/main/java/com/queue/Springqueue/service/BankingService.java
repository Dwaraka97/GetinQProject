package com.queue.Springqueue.service;

public class BankingService {

}
